#ifndef __SHOW_H
#define __SHOW_H
#include "sys.h"

void oled_show(void);
void fill_picture(unsigned char fill_Data);

#endif
