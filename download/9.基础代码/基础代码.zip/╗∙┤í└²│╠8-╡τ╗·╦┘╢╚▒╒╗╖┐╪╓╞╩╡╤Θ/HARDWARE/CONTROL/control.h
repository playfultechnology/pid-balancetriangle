#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"
int TIM1_UP_IRQHandler(void);
int v_x(int Encoder,int target);
void Set_Pwm(int motox);
void Xianfu_Pwm(void);
int myabs(int a);
#endif
