#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"

int TIM1_UP_IRQHandler(void);

void Set_Pwm(int motox,int motoy);

#endif
