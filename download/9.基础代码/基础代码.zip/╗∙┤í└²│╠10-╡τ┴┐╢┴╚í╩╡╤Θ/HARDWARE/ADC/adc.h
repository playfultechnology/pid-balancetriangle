#ifndef __ADC_H
#define __ADC_H	
#include "sys.h"

u16 Get_Adc(u8 ch);
float Get_battery_volt(void);     
void  Baterry_Adc_Init(void);
#endif 















