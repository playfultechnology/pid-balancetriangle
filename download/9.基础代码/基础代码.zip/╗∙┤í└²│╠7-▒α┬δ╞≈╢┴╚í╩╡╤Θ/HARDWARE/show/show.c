#include "show.h"
#include "math.h"

void oled_show(void)
{	
	  OLED_ShowString(0,0,"Vx:",12);       //��������ת�ٶ���ʾ
	  if(Encoder_x>=0){OLED_ShowString(20,0,"+",12);OLED_ShowNum(27,0,Encoder_x,3,12);}
    else          {OLED_ShowString(20,0,"-",12);OLED_ShowNum(27,0,-Encoder_x,3,12);}
		
	}
void fill_picture(unsigned char fill_Data)    //OLED���ͼƬ����
{
	unsigned char m,n;
	for(m=0;m<8;m++)
	{
		OLED_WR_Byte(0xb0+m,0);	//�ӵ�0ҳ����7ҳ
		OLED_WR_Byte(0x00,0);		//low column start address
		OLED_WR_Byte(0x10,0);		//high column start address
		for(n=0;n<128;n++)OLED_WR_Byte(fill_Data,1);	
	}
}



